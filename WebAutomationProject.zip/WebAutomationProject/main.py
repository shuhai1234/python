#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
import os



sys.path.extend(os.path.dirname(os.path.abspath(__file__)))
# print os.path.dirname(os.path.abspath(__file__))

from argparse import ArgumentParser

ap = ArgumentParser(
    #prog = __file__,
    description = 'sip test.',
)
ap.add_argument('case_folder', action="store",type=str, nargs='?', default="milestones/sip1")
ap.add_argument('url', action="store",type=str, nargs='?', default="https://bstest.ienjoys.com")
ap.add_argument('pre_file', action="store",type=str, nargs='?', default="D:/WebAutomationProject/milestones/sip1/precondition.json")
ap.add_argument('number', action="store",type=int, nargs='?', default=0)
ap.add_argument('sleep_time', action="store",type=float, nargs='?', default=0)
args = ap.parse_args()


os.environ.setdefault('CASE_FOLDER', args.case_folder)
os.environ.setdefault('URL', args.url)
os.environ.setdefault('PRE_FILE', args.pre_file)
os.environ.setdefault('UT_ITEM', str(26-1))
os.environ.setdefault('SLEEP_TIME', str(args.sleep_time))

import testRunner
# import jsonRPCTest
testRunner.main()
