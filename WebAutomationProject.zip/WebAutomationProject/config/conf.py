__author__ = 'zhengandy'

url = "http://localhost:8080/xw3"
solr = "http://localhost:8983/solr/"
redis_host = "localhost"
redis_port = 6379
redis_db = 0
preData = {"User1":"13554321888","User2":"13664321999","User3":"13664321000", "User4":"13664322000", "User":"13500044444","MUser1":"13798765888","MUser2":"13898765999","Password":"123456","ResourceMobile1":"13798765123","ResourceMobile2":"13809090909","ResourceMobile3":"13798765100","ResourceMobile4":"13798765101","ResourceMobile5":"13798765102","ResourceMobile6":"13798765103","ResourceMobile7":"13798765104","ResourceMobile8":"13798765105","ResourceMobile9":"13798765106","ResourceMobile10":"13798765107","ResourceMobile11":"13798765108","ResourceMobile12":"13798765109","ResourceMobile13":"13798765110","ResourceMobile14":"13798765111","ResourceMobile15":"13798765112","ResourceMobile16":"13798765113","TUser1":"13510101010","TUser2":"13510101011","TUser3":"13510101012","TUser4":"13510101013","GUser":"13800000000","BUser1":"13794491000","BUser2":"13794491001","BUser3":"13794491002", "BUser4":"13794491003", "BUser":"13794491004","BMUser1":"13794492000","BMUser2":"13794492001","BResourceMobile1":"13794493000","BResourceMobile2":"13794493001","BResourceMobile3":"13794493002","BResourceMobile4":"13794493003","BTUser1":"13794494000","BTUser2":"13794494001","BTUser3":"13794494002","BTUser4":"13794494003","BGUser":"13794495000","Admin":"13511111111","Admin2":"13522222222","Admin3":"13533333333"}
host = "192.168.1.158"
user = "root"
psw = "xwroot*555"
dbname = "xw"
port = 20002
btool = '/usr/local/mysql/bin/mysqldump'
rtool = '/usr/local/mysql/bin/mysql'
url2 = "http://localhost:5000/api/tasks"
restKey = "task"


user_win = "root"
psw_win = "xwroot*555"
dbname_win = "xw"
port_win = 20002
btool_win = 'E:/mysql-5.6.17-winx64/bin/mysqldump'
rtool_win = 'E:/mysql-5.6.17-winx64/bin/mysql'