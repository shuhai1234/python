import re

def type_validator(params, value):
    mark = 0
    if isinstance(params, list):
        if value == "list":
            return True
        for each in params:
            if type(each).__name__ == value:
                mark += 1
        if len(params) == mark:
            return True
    else:
        if type(params).__name__ == value:
            return True
    return False


def type_in_validator(params, value):
    mark = 0
    if isinstance(params, list):
        for each in params:
            if type(each).__name__ in value:
                mark += 1
        if mark == len(params):
            return True
    else:
        if type(params).__name__ in value:
            return True
    return False


def between_validator(params, value):
    mark = 0
    if isinstance(params, list):
        for each in params:
            if not isinstance(params, int):
                return False
            if value[0] <= each  <= value[1]:
                mark += 1
        if mark == len(params):
            return True
    else:
        if not isinstance(params, int):
            return False
        if value[0] <= params  <= value[1]:
            return True
    return False


def values_validator(params, value):
    mark = 0
    if isinstance(params, list):
        for i in xrange(len(params)):
            if params[i] in value:
                mark += 1
        if mark == len(params):
            return True
    else:
        if params in value:
            return True
    return False


def len_validator(params, value):
    mark = 0
    if isinstance(params, list):
        for each in params:
            if len(each) == len(value):
                mark += 1
        if len(params) == mark:
            return True
    else:
        if len(params) == len(value):
            return True
    return False


def equal_validator( params, value):
    if params == value:
        return True
    else:
        return False


def in_validator(param, value):
    if param in value:
        # print "Find the value in index : %d" % value.index(param)
        return True
    else:
        return False


def greater_validator(params, value):
    if params >= value:
        return True
    else:
        return False


def less_validator(params, value):
    if params <= value:
        return True
    else:
        return False


def reg_validator(params, value):
    mark = 0
    if isinstance(params, list):
        for each in params:
            try:
                val = re.match(value, each)
                if val.group(0):
                    mark += 1
            except:
                return False
        if mark == len(params):
            return True
    else:
        try:
            val = re.match(value, params)
            if val.group(0):
                return True
        except:
            return False
    return False


class ValidatorRegistry(object):
    registry = {}
    @classmethod
    def register(cls, name, validate):
        cls.registry[name] = validate

    @classmethod
    def validate(cls, name, params, value):
        return cls.registry[name].validate(params, value)


def checker(typo, params, value):
    val = ValidatorRegistry()
    if typo == "TYPE":
        val.register("TYPE", type_validator(params, value))
    if typo == "LEN":
        val.register("LEN", len_validator(params, value))
    if typo == "LE":
        val.register("LE", less_validator(params, value))
    if typo == "BETWEEN":
        val.register("BETWEEN", between_validator(params, value))
    if typo == "EQ":
        val.register("EQ", equal_validator(params, value))
    if typo == "IN":
        val.register("IN", in_validator(params, value))
    if typo == "GE":
        val.register("GE", greater_validator(params, value))
    if typo == "RE":
        val.register("RE", reg_validator(params, value))
    if typo == "ALLIN":
        val.register("ALLIN", values_validator(params, value))
    if typo == "TYPEIN":
        val.register("TYPEIN", type_in_validator(params, value))
    return val.registry[typo]

