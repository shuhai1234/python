from selenium import webdriver
from time import sleep
import time
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.keys import Keys
dr=webdriver.Firefox()
dr.get('https://bstest.ienjoys.com/index')
dr.find_element_by_name('用户名').send_keys('13428967050')
dr.find_element_by_name('密码').send_keys('sky123456')
time.sleep(5)
dr.find_element_by_css_selector("button").click()

#写位产品
dr.find_element_by_xpath("//*[@id='app']/div/header/div/div[2]/div[2]/span[2]").click()
#获取当前句柄
currentWin = dr.current_window_handle
time.sleep(1)

#定位服务目录
dr.find_element_by_xpath("//*[@id='app']/div/div[2]/div/ul[2]/li[2]").click()
time.sleep(3)

#定位新增
window_1 = dr.current_window_handle
windows = dr.window_handles

for current_window in windows:
    if current_window != window_1:
        dr.switch_to.window(current_window)
dr.find_element_by_xpath("//*[@id='app']/section/div[2]/div[1]/span[4]/button/span").click()

#定位服务名称
dr.find_element_by_xpath("//*[@id='app']/section/div[2]/form/div[1]/div[1]/span[1]/div/div/div[1]/input").send_keys("hhhh")

#定位服务类目
dr.find_element_by_xpath("//*[@id='app']/section/div[2]/form/div[1]/div[1]/span[2]/div/div/div").click()
#定位服务类目页面中的增加按钮
time.sleep(5)
dr.find_element_by_xpath("//*[@id='app']/section/div[2]/div[2]/div/div[2]/div[1]/span[2]").click()

#输入类目名称
dr.find_element_by_xpath("//*[@id='app']/section/div[2]/div[2]/div/div[2]/ul/div/li[1]/div/input").send_keys("类目3")
#选择一个类目
dr.find_element_by_xpath("//*[@id='app']/section/div[2]/div[2]/div/div[2]/ul/div/li[1]/label/span[1]/span").click()

#拖动滚动条
#js="document.getElementByClassName('serviceListContent')[0].scrollTop=10000"  #到底部
#dr.execute_script(js)

#js="var q=document.getElementById('id').scrollTop=0" #回去顶部
#dr.execute_script(js)

#确定
dr.find_element_by_xpath("//*[@id='app']/section/div[2]/div[2]/div/div[2]/div[2]/button/span").click()
time.sleep(4)
#属性组合
dr.find_element_by_xpath("//*[@id='app']/section/div[2]/form/div[1]/div[2]/span/div/div/div/input").click()
time.sleep(3)
#搜索
search=dr.find_element_by_xpath("//*[@id='attributeSetShow']/div/div[2]/div[1]/div/input").send_keys("水费类")
dr.find_element_by_xpath("//*[@id='attributeSetShow']/div/div[2]/div[1]/button").click()
dr.find_element_by_xpath("//*[@id='attrList']/div[3]/table/tbody/tr/td[1]/div/div/label/span[1]/span").click()
#确定
dr.find_element_by_xpath("//*[@id='attributeSetShow']/div/div[2]/div[3]/button/span").click()

dr.find_element_by_xpath("//*[@id='app']/section/div[2]/form/div[1]/div[3]/span[2]/div/textarea").send_keys("1113141412414214")
#定位确认
time.sleep(5)
dr.find_element_by_xpath("//*[@id='app]/section/div[2]/form/div[2]/button/span").click()
dr.find_element_by_xpath("//*[@id='app']/section/div[2]/form/div[2]/button/span").click()




#dr.find_element_by_xpath("//*[@id='attributeSetShow'']").click()
# 截取当前窗口
dr.get_screenshot_as_file("D:\\服务目录新增页面_img.jpg")
dr.quit()










