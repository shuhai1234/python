from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support.select import Select
from selenium import webdriver
import time
class pyse():
#定义驱动
    def __init__(self, browser=None,timeout=None):
        if browser is None or browser=="firefox"or browser=="ff":
            self.driver=webdriver.Firefox()
        elif browser=="chrome"or browser=="ch":
            self.driver=webdriver.Chrome()
        else:
            raise  NameError("浏览器参数错误")
        if timeout is None:
            self.timeout=5
        else:
            self.timeout=None

        #定义打开浏览器
    def open(self,url):
        self.driver.get(url)
        #定义关闭浏览器
    def close(self):
        self.driver.close()
   #定义等待时间
    def sleep(sec,self):
        time.sleep(sec)
    #定义元素等待
    def wait_element(self,elemrnt):

        try:
            WebDriverWait(self.driver, self.timeout).until(
                EC.presence_of_element_located(elemrnt)
            )
        except TimeoutException:
            return False
        else:
            return True

    def get_element(self, ele):
                "name=>用户名"
                "xpath=>//*[@id=‘app’]/section/div/div[1]/div[2]/form/div[1]/input"
                if "=>" not in ele:
                    by = "css"
                    value = ele
                else:
                    by = ele.split("=>")[0]
                    value = ele.split("=>")[1]

                time_out_error = "定位元素超时，请尝试其他定位方式"
                if by == "id":
                    req = self.wait_element((By.ID, value))
                    if req is True:
                        element = self.driver.find_element_by_id(value)
                    else:
                        raise TimeoutException(time_out_error)
                elif by == "name":
                    req = self.wait_element((By.NAME, value))
                    if req is True:
                        element = self.driver.find_element_by_name(value)
                    else:
                        raise TimeoutException(time_out_error)
                elif by == "class":
                    req = self.wait_element((By.CLASS_NAME, value))
                    if req is True:
                        element = self.driver.find_element_by_class_name(value)
                    else:
                        raise TimeoutException(time_out_error)
                elif by == "link_text":
                    req = self.wait_element((By.LINK_TEXT, value))
                    if req is True:
                        element = self.driver.find_element_by_link_text(value)
                    else:
                        raise TimeoutException(time_out_error)
                elif by == "xpath":
                    req = self.wait_element((By.XPATH, value))
                    if req is True:
                        element = self.driver.find_element_by_xpath(value)
                    else:
                        raise TimeoutException(time_out_error)
                elif by == "css":
                    req = self.wait_element((By.CSS_SELECTOR, value))
                    if req is True:
                        element = self.driver.find_element_by_css_selector(value)
                    else:
                        raise TimeoutException(time_out_error)
                else:
                    raise NameError("定位方式不存在")
                return element
    def input (self,element,text):
        el =self.get_element(element)
        el.send_keys(text)
    def click(self,element):
        el=self.get_element(element)
        el.click()















