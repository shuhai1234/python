from pyse import pyse
import time
from selenium import webdriver
dr=pyse()
dr.open("https://bstest.ienjoys.com/index")
dr.input("#用户名","13428967050")
dr.input("#密码","s123456")
dr.click("#登录")
time.sleep(3)
dr.close()








