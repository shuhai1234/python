# coding=utf-8

from appium import webdriver
import time
import  unittest
import os
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.select import Select
# 获取项目的根目录路径
#p = os.path.abspath(os.path.join(os.path.dirname(os.path.realpath(__file__)),".."))
# 获取app路径
#appPath = lambda x:os.path.join(p, "app", x)
#print(appPath("V2.9.6.apk"))

desired_caps = {
                'platformName': 'Android',
                'deviceName': '5591d0a9',
                'platformVersion': '5.1.1',
                'appPackage': 'com.gkeeper.client',
                'appActivity': 'com.gkeeper.client.ui.main.IndexActivity',
                'unicodeKeyboard': True,
                'resetKeyboard': True
                }
driver = webdriver.Remote('http://127.0.0.1:4723/wd/hub', desired_caps)
time.sleep(5)
#登录
#driver.find_element_by_id("com.gkeeper.client:id/et_mobile").send_keys("13428967050")
#driver.find_element_by_id("com.gkeeper.client:id/et_passcode").send_keys("a123456")
#driver.find_element_by_id("com.gkeeper.client:id/btn_submit").click()

#开始工作
driver.find_element_by_id("com.gkeeper.client:id/centerImage2").click()
#签入技能
driver.find_element_by_name("深圳乐享家园").click()
driver.find_element_by_name("家政维修").click()
driver.find_element_by_name("客户服务").click()

def getSize():
    x = driver.get_window_size()['width']
    y = driver.get_window_size()['height']
    return (x, y)

#屏幕向上滑动
def swipeUp(t=500,n=10):
   l = getSize()
   x1 = int(l[0] * 0.5)    #x坐标
   y1 = int(l[1] * 0.5)   #起始y坐标
   y2 = int(l[1] * 0.25)   #终点y坐标
   for i in range(n):
    driver.swipe(x1, y1, x1, y2,t)
swipeUp(1000)
driver.find_element_by_name("指派工单").click()
driver.find_element_by_name("车场管理").click()
driver.find_element_by_name("关闭工单").click()
driver.find_element_by_id("com.gkeeper.client:id/centerImage2").click()
time.sleep(3)
#点击结束工作图标
driver.find_element_by_id("com.gkeeper.client:id/centerImage2").click()
time.sleep(2)
#点击”事件申报“
driver.find_element_by_xpath("//*[@text='事件申报']").click()
time.sleep(3)
driver.find_element_by_id("com.gkeeper.client:id/layout_s").click()
time.sleep(3)
#选择房屋信息
driver.find_element_by_xpath("//*[@text='深圳中兴人才公寓']").click()

#打印出坐标
#text = driver.find_elements_by_class_name('android.widget.TextView')
#num = -1
#for i in text:
   #num += 1
  # print(num,i.get_attribute('name'))

elements1=driver.find_elements_by_class_name("android.widget.TextView")
elements1[6].click()
time.sleep(5)

driver.find_element_by_xpath("//*[@text='中兴人才公寓']").click()

def getSize():
    x = driver.get_window_size()['width']
    y = driver.get_window_size()['height']
    return (x, y)

#屏幕向上滑动
def swipeUp(t=500,n=2):
   l = getSize()
   x1 = int(l[0] * 0.5)    #x坐标
   y1 = int(l[1] * 0.75)   #起始y坐标
   y2 = int(l[1] * 0.25)   #终点y坐标
   for i in range(n):
       driver.swipe(x1, y1, x1, y2,t)
swipeUp(1000)

driver.find_element_by_name("方法更").click()
driver.find_element_by_id("com.gkeeper.client:id/btn_submit").click()
driver.find_element_by_id("com.gkeeper.client:id/tv_type").click()
time.sleep(2)
driver.find_element_by_xpath("//*[@text='公共清洁']").click()
driver.find_element_by_id("com.gkeeper.client:id/et_content").send_keys("123456rt")
driver.find_element_by_id("com.gkeeper.client:id/iv_image").click()
time.sleep(3)
driver.find_element_by_xpath("//*[@text='拍摄照片']").click()
driver.find_element_by_id("com.oppo.camera:id/shutter_button").click()
time.sleep(3)
driver.find_element_by_id("com.oppo.camera:id/btn_done").click()
time.sleep(2)
driver.find_element_by_xpath("//*[@text='预约服务时间']").click()

driver.tap([(0, 1041), (540, 1800)], 500)

def swipeUp(t=500,n=2):
   l = getSize()
   x1 = int(l[0] * 0.5)    #x坐标
   y1 = int(l[1] * 0.75)   #起始y坐标
   y2 = int(l[1] * 0.25)   #终点y坐标
   for i in range(n):
       driver.swipe(x1, y1, x1, y2, t)
   swipeUp(1000)
driver.find_element_by_id("com.gkeeper.client:id/btn_submit").click()
driver.find_element_by_id("com.gkeeper.client:id/btn_submit").click()

if __name__ == "__main__":
    testunit = unittest.TestSuite()
    testunit.addTest(LoginTest("test_login"))
# 定义报告存放路径
    now = time.strftime("%Y-%m-%d %H_%M_%S")
    filename = '.\\report\\.' + now + 'result.html'
    fp = open(filename, 'wb')
runner =HTMLTestRunner(stream=fp,
                            title='登录的测试报告',
                            description='用例执行情况：')
runner.run(testunit)  # 运行测试用例
fp.close()









