import time
from  selenium import  webdriver
driver=webdriver.Firefox()
driver.get('https://property.ienjoys.com/ehome/')

ele = driver.find_element_by_class_name('reg_user')
ele.send_keys('18664323315')
ele = driver.find_element_by_class_name('reg_secret')
ele.send_keys('18664323315')
time.sleep(10)
driver.find_element_by_class_name('login_bottom').click()
time.sleep(5)
driver.find_element_by_xpath('//div[@class="menu_title"]/div[@class="left"]').click()
time.sleep(1)
driver.find_element_by_xpath('//a[@id="menuA_0"]').click()
time.sleep(3)

#time=driver.find_element_by_xpath('//input[@id="startEffectiveDate"]').click()
#time.send_keys("2018-12-25")

#定位时间控件
#js = '$(\'input[id=startEffectiveDate]\').removeAttr(\'readonly\')'
#driver.execute_script(js)
#js_value=driver.find_element_by_id("startEffectiveDate")
#js_value.send_keys("2019-01-13")
#time.sleep(3)

#driver.find_element_by_xpath("//*[@id='dataForm']/div[1]/div[12]/a").click()

#新增商品
driver.find_element_by_xpath("//*[@id='dataForm']/div[3]/div[2]/a").click()
time.sleep(3)

#定位名称
#driver.find_element_by_xpath(" //*[@id='adName']").send_keys('123')
#定位上线时间
#driver.find_element_by_xpath("/html/body/div[2]/div[2]/div[2]/form/table/tbody/tr[3]/td[2]/span[2]").click()
#driver.execute_script(js)
#js_value=driver.find_element_by_id("effectiveDate").send_keys("2019-01-13")
#time.sleep(3)
#定位下线时间
#driver.find_elements_by_xpath("//*[@id='dataForm']/table/tbody/tr[4]/td[2]/input[1]").click()
#定位banner图片

#排序值
#driver.find_element_by_xpath("//*[@id='dataForm']/table/tbody/tr[6]/td[2]/input").send_keys(5)
#发布范围
#driver.find_element_by_xpath("//*[@id='trProject']/td[2]/div[2]/a").click()
#driver.find_element_by_xpath("//*[@id='projectTree_1_switch']").click()
#driver.find_element_by_xpath("//*[@id='projectTree_2_span']").click()
#driver.find_element_by_xpath("//*[@id='projectPlan']/div[4]/button[2]").click()




#定位banner跳转
#driver.find_element_by_xpath('//*[@id="keyWord"]')
#点击”选择“
driver.find_element_by_xpath("//*[@id='goodsDiv']/div/a").click()
#time.sleep(5)
#定位类别
search_windows=driver.current_window_handle
all_handles=driver.window_handles
#类别选择窗口
for handle in all_handles:
    if handle !=search_windows:
        driver.switch_to_window(handle)
        print("now regester window")
        dr = driver.find_element_by_xpath("//*[@id='keyWord']").click()
        dr.send_keys("生鲜果蔬")




driver.find_element_by_xpath("//*[@id='dataForm']/div[2]/table/tbody/tr[2]/td[1]/input[1]").click()



#Goodpnam = ["","yanhui","生活类"]
#or para in Goodpnam:
    #le.clear()
    #ele.send_keys(para)
    #time.sleep(2)
#search=driver.find_element_by_xpath('//a[@onclick="seach()"]')
#search.click()


time.sleep(2)
driver.quit()




