from selenium import webdriver
import unittest
import time
class login(unittest.TestCase):
    def setUp(self):
        self.dr=webdriver.Firefox()
        url="http://47.106.151.121/index"
        self.dr.get("url")
        time.sleep(2)
    def login(self,username,psw,yzm):
        self.dr.find_element_by_xpath("//*[@id='app']/section/div/div[1]/div[2]/form/div[1]/input").send_keys("username")
        self.dr.find_element_by_xpath("//*[@id='app']/section/div/div[1]/div[2]/form/div[2]/input").send_keys("psw")
        self.dr.find_element_by_xpath("/html/body/div/section/div/div[1]/div[2]/form/div[3]/input").send_keys("yzm")
        self.dr.find_element_by_xpath("//*[@id='app']/section/div/div[1]/div[2]/div[1]/button").click()
        time.sleep(2)


def is_login_sucess(self):
    u'''判断是否获取到登录账户名称'''
    try:
        text = self.driver.find_element_by_xpath("//*[@id='app']/div/header/div/div[1]/div/span[4]/font").text
        print (text)
        return True
    except:
        return False


def test_01(self):
    u'''登录案例参考:账号，密码自己设置'''
    self.login(u"18565697188", u"Aa123456",u"8888")  # 调用登录方法
    # 判断结果
    result = self.is_login_sucess()
    self.assertTrue(result)

def test_02(self):
    self.login(u"18565697188")#调用登录方法
    text = self.driver.find_element_by_xpath("//*[@id='app']/div/header/div/div[1]/div/span[4]/font").text    # 获取登录后的账号名称
    print (text)
    self.assertEqual(text, u"18565697188")   # 断言实际结果与期望结果一致



def tearDown(self):
    self.driver.quit()

    if __name__ == "__main__":
        testunit = unittest.TestSuite()
        testunit.addTest(login("test_login"))
        # 定义报告存放路径
        now = time.strftime("%Y-%m-%d %H_%M_%S")
        filename = '.\\report\\.' + now + 'result.html'
        fp = open(filename, 'wb')
    runner = HTMLTestRunner(stream=fp,
                            title='登录的测试报告',
                            description='用例执行情况：')
    runner.run(testunit)  # 运行测试用例
    fp.close()










