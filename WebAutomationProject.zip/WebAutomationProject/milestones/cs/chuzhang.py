from selenium import webdriver
from time import sleep
import time
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.keys import Keys
dr=webdriver.Firefox()
dr.get('https://bstest.ienjoys.com/index')
dr.find_element_by_name('用户名').send_keys('13428967050')
dr.find_element_by_name('密码').send_keys('sky123456')
time.sleep(5)
dr.find_element_by_css_selector("button").click()


#定位到要悬停的元素（定位账务)
dr.find_element_by_xpath("//*[@id='app']/div/header/div/div[2]/div[2]/span[4]").click()
time.sleep(3)
#获取当前句柄
currentWin = dr.current_window_handle
time.sleep(1)

#定位出账
implement=dr.find_element_by_xpath(".//*[@id='app']/div[1]/div[4]/div/ul[1]/li[4]")
ActionChains(dr).move_to_element(implement).perform()
implement.click()
time.sleep(2)


#新建出账任务
window_1 = dr.current_window_handle
windows = dr.window_handles

for current_window in windows:
    if current_window != window_1:
        dr.switch_to.window(current_window)
dr.find_element_by_xpath("//*[@id='app']/main/div[1]/span[4]/a/button/span").click()


#在选择框中选择服务中心
s1=dr.find_element_by_xpath("//*[@id='app']/main/div[2]/form/div[1]/div/span/span/span")
ActionChains(dr).click(s1).perform()
time.sleep(2)
dr.find_element_by_xpath('/html/body/div[2]/ul[2]/li[2]').click()


#输入任务名称
dialog_box=dr.find_element_by_xpath("//*[@id='app']/main/div[2]/form/div[2]/div/div/input").send_keys('2')
time.sleep(3)
#清空输入框内容
#dialog_box.send_keys(Keys.CONTROL,'a')
#dialog_box.send_keys(Keys.SPACE)
#time.sleep(1)


#选择日期控件　
dr.find_element_by_xpath('//*[@id="app"]/main/div[2]/form/div[3]/div/div[1]/div/div/div/input').click()
dr.find_element_by_xpath("/html/body/div[3]/div[1]/div/div[2]/table[3]/tbody/tr[2]/td[4]/a").click()
time.sleep(2)
dr.find_element_by_xpath("//*[@id='app']/main/div[2]/form/div[3]/div/div[3]/div/div/div/input").click()
dr.find_element_by_xpath("/html/body/div[4]/div[1]/div/div[2]/table[3]/tbody/tr[3]/td[1]/a").click()

#选择出账范围
dr.find_element_by_xpath("//*[@id='app']/main/div[2]/form/div[4]/div/div/label[2]/span[2]").click()  #选择自定义
dr.find_element_by_xpath("//*[@id='app']/main/div[2]/form/div[5]/div/div/div/button/span").click()  #选择
dr.find_element_by_xpath("//*[@id='resource-dialog']/div/div[2]/div/div[1]/div/div/div/div[2]/div/div[1]").click()
dr.find_element_by_xpath("//*[@id='resource-dialog']/div/div[2]/div/div[2]/div/div/div[2]/label/span[2]").click()
dr.find_element_by_xpath("//*[@id='resource-dialog']/div/div[3]/span/button[1]/span").click()

#选择出账产品
#dr.find_element_by_xpath("/html/body/div[1]/main/div[2]/form/div[6]/div[1]/div/div/div/label[2]/span[2]").click()
#dr.find_element_by_xpath("/html/body/div[1]/main/div[2]/form/div[6]/div[2]/div/div/div[2]/div/div/label/span[2]").click()

#点击”出账任务“按钮
dr.find_element_by_xpath("//*[@id='app'/main/div[3]/button/span").click()















