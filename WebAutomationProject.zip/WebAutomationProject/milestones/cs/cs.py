from selenium import webdriver
from time import sleep
import time
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.keys import Keys
from HTMLTestRunner import HTMLTestRunner
import unittest
class Chuzhang(unittest.TestCase):
    def setUp(self):
        dr=webdriver.Firefox()
        time.sleep(5)
        dr.get('https://bstest.ienjoys.com/index')

    def test_login(self):
        dr=self.driver
        dr.find_element_by_xpath('//*[@id="app"]/section/div/div[1]/div[2]/form/div[1]/input').send_keys('13428967050')
        dr.find_element_by_xpath('//*[@id="app"]/section/div/div[1]/div[2]/form/div[2]/input').send_keys('sky123456')
        time.sleep(5)
        dr.find_element_by_css_selector("button").click()

    def tearDown(self):
        self.driver.quit()

if __name__ == "__main__":
    testunit = unittest.TestSuite()
testunit.addTest(Chuzhang("test_login"))
    # 定义报告存放路径
fp = open('./result.html', 'wb')
    # 定义测试报告
runner = HTMLTestRunner(stream=fp,
                            title='出账的测试报告',
                            description='用例执行情况：')
runner.run(testunit)  # 运行测试用例
fp.close()
