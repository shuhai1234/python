# coding=utf-8

from appium import webdriver
import time
import  unittest
import os
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.select import Select
# 获取项目的根目录路径
#p = os.path.abspath(os.path.join(os.path.dirname(os.path.realpath(__file__)),".."))
# 获取app路径
#appPath = lambda x:os.path.join(p, "app", x)
#print(appPath("V2.9.6.apk"))

desired_caps = {
                'platformName': 'Android',
                'deviceName': '5591d0a9',
                'platformVersion': '5.1.1',
                'appPackage': 'com.gemdale.client',
                'appActivity': 'com.enjoylink.client3.index.IndexActivity',
                'unicodeKeyboard': True,
                'resetKeyboard': True
                }
driver = webdriver.Remote('http://127.0.0.1:4723/wd/hub', desired_caps)
time.sleep(5)


def test_case(self):
    driver = self.driver
#左滑动
def getSize():
    x = driver.get_window_size()['width']
    y = driver.get_window_size()['height']
    return (x, y)

def swipLeft(t=500,n=3):
    l=getSize()
    x1=int(l[0]*0.75)
    y1=int(l[1]*0.5)
    x2=int(l[0]*0.05)
    for i in range(n):
        time.sleep(3)
        driver.swipe(x1, y1, x2, y1, t)
swipLeft(1000)
#点击“立即开启”
driver.find_element_by_id("com.gemdale.client:id/bt_button_view").click()
time.sleep(3)

#短信验证码登录
driver.find_element_by_id("com.gemdale.client:id/et_mobile").send_keys("13428967050")
driver.find_element_by_id("com.gemdale.client:id/btn_passcode").click()
driver.find_element_by_id("com.gemdale.client:id/btn_submit").click()


#对密码进行修改
#driver.find_element_by_xpath("//*[@text='账号密码登录']").click()
#点击忘记密码
#driver.find_element_by_id("com.gemdale.client:id/et_mobile").send_keys("13428967050")
#driver.find_element_by_id("com.gemdale.client:id/btn_passcode").click()
#driver.find_element_by_id("com.gemdale.client:id/btn_passcode").click()
#driver.find_element_by_id("com.gemdale.client:id/et_passcode").send_keys("9999")
#driver.find_element_by_id("com.gemdale.client:id/et_password").send_keys("s12345678")
#driver.find_element_by_id("com.gemdale.client:id/et_repassword").send_keys("s12345678")
#driver.find_element_by_id("com.gemdale.client:id/btn_reset_password").click()
time.sleep(5)

#进行账号密码登录
#driver.find_element_by_xpath("//*[@text='账号密码登录']").click()
#driver.find_element_by_id("com.gemdale.client:id/et_mobile").send_keys("13428967050")
#driver.find_element_by_id("com.gemdale.client:id/et_passcode").send_keys("s12345678")
#driver.find_element_by_id("com.gemdale.client:id/btn_submit").click()
#time.sleep(5)

#切换房屋
#driver.find_element_by_id("com.gemdale.client:id/tv_select_project").click()
#time.sleep(4)

#t向上滑动
#def getSize():
    #x = driver.get_window_size()['width']
    #y = driver.get_window_size()['height']
   # return (x, y)

#屏幕向上滑动
#def swipeUp(t):
    #l = getSize()
   # x1 = int(l[0] * 0.5)    #x坐标
    #y1 = int(l[1] * 0.75)   #起始y坐标
    #y2 = int(l[1] * 0.25)   #终点y坐标
    #driver.swipe(x1, y1, x1, y2,t)
#swipeUp(1000)
#time.sleep(3)
#driver.find_element_by_xpath("//*[@text='深圳金地上塘道1栋1单元3A']").click()
#driver.find_element_by_xpath("//*[@text='确定']").click()
#time.sleep(3)


#定位社区
#driver.find_element_by_id("com.gemdale.client:id/rb_service").click()
#time.sleep(3)

# 获取屏幕的size
#size = driver.get_window_size()
#print(size)
# 获取屏幕宽度 width
#width = size['width']
#print(width)
# 获取屏幕高度 height
#height = size['height']
#print(height)

#def getSize():
    #x = driver.get_window_size()['width']
    #y = driver.get_window_size()['height']
    #return (x, y)

#屏幕向上滑动
#def swipeUp(t):
    #l = getSize()
    #x1 = int(l[0] * 0.5)    #x坐标
    #y1 = int(l[1] * 0.75)   #起始y坐标
    #y2 = int(l[1] * 0.25)   #终点y坐标
    #driver.swipe(x1, y1, x1, y2,t)
#swipeUp(1000)

#点击我要发贴
#driver.find_element_by_id('com.gemdale.client:id/tv_release').click()
#driver.find_element_by_id("com.gemdale.client:id/tet_content").send_keys("rtyrturtuurturt")
#调用拍照
#driver.find_element_by_id("com.gemdale.client:id/iv_pic").click()
#driver.find_elements_by_class_name("android.widget.FrameLayout").click()
#driver.find_element_by_id("com.oppo.camera:id/btn_done").click()
#driver.sendKeyEvent(27)
#发布
#driver.find_element_by_id("com.gemdale.client:id/tet_content").click()


#定位车辆模块
#driver.find_element_by_id("com.gemdale.client:id/iv_add_car").click()
#点击添加车辆
#driver.find_element_by_id("com.gemdale.client:id/tv_car_numbers").click()
#输入车牌信息
#driver.find_element_by_id("com.gemdale.client:id/tv_belong").click()
#driver.find_element_by_xpath("//*[@text='鲁']").click()
#driver.find_element_by_id("com.gemdale.client:id/input_park_number").send_keys("123456")
#driver.find_element_by_id("com.gemdale.client:id/btn_submit").click()
#输入验证码
#driver.find_element_by_id("com.gemdale.client:id/et_passcode").send_keys("9999")
#driver.find_element_by_id("com.gemdale.client:id/btn_submit").click()
#time.sleep(3)



#服务
#driver.find_element_by_xpath("//*[@text='全部服务']").click()
#time.sleep(5)
#driver.find_element_by_xpath("//*[@text='公共报事']").click()

#系统默认的权限弹框
#def always_allow(driver, number=5):
    #for i in range(number):
        #loc = ("xpath", "//*[@text='允许']")
        #try:
            #e = WebDriverWait(driver, 1, 0.5).until(EC.presence_of_element_located(loc))
           # e.click()
        #except:
           # pass
#always_allow(driver)
#time.sleep(3)

#driver.find_element_by_id("com.gemdale.client:id/rl_select_type").click()
#time.sleep(3)
#driver.find_element_by_xpath("//*[@text='公共清洁']").click()
#time.sleep(3)
#driver.find_element_by_id("com.gemdale.client:id/et_report_content").send_keys("1225325reyrrtytrurtu")
#拍照
#driver.find_element_by_id("com.gemdale.client:id/iv_pic").click()
#time.sleep(3)
#driver.sendKeyEvent(27）
#driver.find_element_by_id("com.oppo.camera:id/btn_done").click()

#选择时间控件
#driver.find_element_by_id("com.gemdale.client:id/rl_service_time").click()
#time.sleep(3)

#def getSize():
    #x = driver.get_window_size()['width']
   # y = driver.get_window_size()['height']
   # return (x, y)

#屏幕向上滑动
#def swipeUp(t):
   # l = getSize()
   # x1 = int(l[0] * 0.5)    #x坐标
    #y1 = int(l[1] * 0.75)   #起始y坐标
    #y2 = int(l[1] * 0.25)   #终点y坐标
    #driver.swipe(x1, y1, x1, y2,t)
#swipeUp(1000)

#driver.find_element_by_xpath("//*[@text='确定']").click()
#driver.find_element_by_id("com.gemdale.client:id/btn_submit").click()


#物品放行
driver.find_element_by_xpath("//*[@text='全部服务']").click()
time.sleep(5)
driver.find_element_by_xpath("//*[@text='物品放行']").click()
time.sleep(5)
driver.find_element_by_xpath("//*[@text='申请放行条']").click()
#删除物品输入框
driver.find_element_by_id("com.gemdale.client:id/im_view").click()
#输入物品信息
driver.find_elements_by_id("com.gemdale.client:id/et_view_input")[0].send_keys("柜子")
driver.find_elements_by_id("com.gemdale.client:id/tv_add")[0].click()
driver.find_elements_by_id("com.gemdale.client:id/tv_add")[0].click()
driver.find_elements_by_id("com.gemdale.client:id/et_view_input")[1].send_keys("衣服")
driver.find_elements_by_id("com.gemdale.client:id/tv_add")[1].click()
#增加物品输入框
driver.find_element_by_xpath("//*[@text='添加']").click()
#选择搬运时间
driver.find_element_by_xpath("//*[@text='请选择时间']").click()
def getSize():
    x = driver.get_window_size()['width']
    y = driver.get_window_size()['height']
    return (x, y)

#屏幕向上滑动
def swipeUp(t=500,n=2):
   l = getSize()
   x1 = int(l[0] * 0.5)    #x坐标
   y1 = int(l[1] * 0.75)   #起始y坐标
   y2 = int(l[1] * 0.25)   #终点y坐标
   for i in range(n):
       time.sleep(3)
   driver.swipe(x1, y1, x1, y2,t)
swipeUp(1000)

driver.find_element_by_id("com.gemdale.client:id/view_confirm").click()
#点击“提交”
driver.find_element_by_id("com.gemdale.client:id/tv_button_take").click()

#切换输入法：
def switch_ime(nme_name):
    """
    对设备切换输入法
    :param nme_name: 需要 切换的输入法特立简称
    :return: 无法返回
    """
    ime_all=os.popen("adb shell ime list _s").readlines()
    try:
        for i in range(len(ime_all)):
            if str(ime_name)in ime_all[i]:
                os.popen("adb shell ime set"+ime_all[i])
                return None
            raise Exception("error!没有{}输入法！".format(ime_all))
    except Exception as error:
        raise Exception(error)


#生活缴费
#driver.find_element_by_xpath("//*[@text='全部服务']").click()
#time.sleep(5)
#driver.find_element_by_xpath("//*[@text='外拓缴费']").click()
#time.sleep(5)
#点击立即缴费
#driver.find_element_by_id("com.gemdale.client:id/tv_pay_at_now").click()
#选择微信支付
#driver.find_element_by_id("com.gemdale.client:id/rl_weixin_pay").click()
#确认支付
#driver.find_element_by_id("com.gemdale.client:id/btn_submit").click()


if __name__ == '__main__':

    pass